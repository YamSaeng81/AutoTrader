SYSLOG=/d/tmp/v171d4s/sim/runs/s1-c01/fix/syslog   # 대역 치환: 가짜 시스템 기록(실제 /var/log/syslog 는 서버에만 있다)
