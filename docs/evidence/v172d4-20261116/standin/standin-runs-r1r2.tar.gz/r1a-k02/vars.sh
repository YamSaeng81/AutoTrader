SYSLOG=/d/tmp/v172d4s/sim/runs/r1a-k02/fix/syslog   # 대역 치환: 가짜 시스템 기록(실제 /var/log/syslog 는 서버에만 있다)
